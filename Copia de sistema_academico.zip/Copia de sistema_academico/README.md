# Sistema Académico (Django)

```
python -m venv venv
venv\Scripts\activate          # Mac/Linux: source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py poblar_datos   # datos de prueba (ya vienen en db.sqlite3)
python manage.py runserver
```

Abre http://127.0.0.1:8000/ · Usuario de prueba: `admin` / `admin12345` (cámbiala).

Pruebas automáticas: `python manage.py test`
