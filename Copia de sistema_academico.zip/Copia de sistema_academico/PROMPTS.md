# Bitácora de prompts · Sistema Académico

> Borrador para tu entrega (1 punto). Revísalo, reescríbelo con tus palabras y agrega lo que a TI te falló.

| # | Prompt | Qué se pidió | Qué falló | Cómo se corrigió |
|---|--------|--------------|-----------|------------------|
| 0 | Contexto del proyecto | Reglas fijas: solo vistas de clase, LoginRequiredMixin primero, nombres en español | — | — |
| 1 | Crear los modelos | `ModeloBase` + 11 modelos, `Nota.save()`, `Matricula.clean()` | — | Se usó el código de referencia de la guía |
| 2 | Admin y datos de prueba | `BaseAdmin`, inline de Nota, comando `poblar_datos` | — | `get_or_create`: ejecutarlo 2 veces no duplica |
| 3 | Base del proyecto | settings, urls, `base.html`, login, `InicioView` | `LOGIN_REDIRECT_URL = "inicio"` no existe porque la app tiene `app_name` | Se usó `"academico:inicio"` |
| 4 | CRUD básico de Estudiante | Form con validación de cédula, 5 vistas, templates | — | — |
| 5 | Filtros + columnas | `FiltroCamposMixin`, `valor_campo`, `_filtros.html` | Los enlaces de Excel/PDF repetían una columna no permitida (`?campos=user__password`) | `consulta` solo conserva columnas de `campos_disponibles` |
| 6 | Excel | `exportar_excel`, `ExportarMixin` | El ancho de columna lo fijaba el título largo de la fila 1 | Se calcula solo con encabezados y datos |
| 7 | PDF del listado | `render_pdf`, `link_callback`, `listado.html` | `settings.MEDIA_ROOT / ...` falla si MEDIA_ROOT es un texto | Se envuelve con `Path(...)` |
| 8 | Comprobante PDF | `ComprobantePdfMixin` | Una nota de 0 salía como «—» por el filtro `default` | Se cambió por `{% if x.nota %}` |
| 9 | CRUD Matrícula + Nota | `inlineformset_factory`, transacción | La pantalla de Matrícula no tenía título/prefijo (faltaba `CrudContextoMixin`) | Se agregó al `MatriculaNotaMixin` |
| 10–11 | Componentes en Matrículas + comprobante | Solo configuración | — | — |
| Plantilla | 8 CRUD restantes | Mismo patrón con la tabla 6.3 | — | — |
