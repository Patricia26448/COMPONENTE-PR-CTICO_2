# =====================================================================
# core/forms.py · ayudas para formularios (Bootstrap 5)
# =====================================================================
from django import forms


class FechaInput(forms.DateInput):
    """Campo de fecha del navegador (type="date"). El formato Y-m-d es el que entiende el navegador."""
    input_type = "date"

    def __init__(self, attrs=None):
        super().__init__(attrs=attrs, format="%Y-%m-%d")


class BootstrapFormMixin:
    """Agrega las clases de Bootstrap a todos los widgets del formulario."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for campo in self.fields.values():
            widget = campo.widget
            if isinstance(widget, forms.CheckboxInput):
                clase = "form-check-input"
            elif isinstance(widget, (forms.Select, forms.SelectMultiple)):
                clase = "form-select"
            else:
                clase = "form-control"
            widget.attrs["class"] = f"{widget.attrs.get('class', '')} {clase}".strip()


class BootstrapForm(BootstrapFormMixin, forms.Form):
    """Formulario normal (para los filtros) con Bootstrap."""


class BootstrapModelForm(BootstrapFormMixin, forms.ModelForm):
    """ModelForm con Bootstrap."""
