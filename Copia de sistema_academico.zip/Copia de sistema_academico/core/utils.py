# =====================================================================
# core/utils.py · funciones reutilizables (no conocen ningún modelo del negocio)
# =====================================================================
from datetime import date, datetime
from decimal import Decimal
from io import BytesIO
from pathlib import Path

from django.conf import settings
from django.http import HttpResponse
from django.template.loader import render_to_string
from django.utils import formats, timezone
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from xhtml2pdf import pisa


# ---------------------------------------------------------------------
# 1. Leer un dato por su ruta con "__"
# ---------------------------------------------------------------------
def valor_campo(objeto, ruta):
    """Lee un dato siguiendo una ruta con "__": valor_campo(est, "carrera__facultad__nombre").
    - Si el campo tiene choices, devuelve el texto (get_X_display).
    - Si en el camino algo no existe (ej. una matrícula sin nota), devuelve "".
    """
    for parte in ruta.split("__"):
        if objeto is None:
            return ""
        display = getattr(objeto, f"get_{parte}_display", None)   # si es un campo con choices, usa su texto
        try:
            objeto = display() if display else getattr(objeto, parte, "")
        except Exception:                                          # ej. matricula.nota cuando no hay nota
            return ""
        if callable(objeto):                                       # métodos sin parámetros
            objeto = objeto()
    return "" if objeto is None else objeto


# ---------------------------------------------------------------------
# 2. Dar formato a los valores (pantalla, PDF y Excel muestran lo mismo)
# ---------------------------------------------------------------------
def texto_valor(valor):
    """Convierte cualquier valor en un texto legible."""
    if isinstance(valor, bool):
        return "Sí" if valor else "No"
    if isinstance(valor, datetime):
        return timezone.localtime(valor).strftime("%d/%m/%Y %H:%M") if timezone.is_aware(valor) else valor.strftime("%d/%m/%Y %H:%M")
    if isinstance(valor, date):
        return valor.strftime("%d/%m/%Y")
    if isinstance(valor, Decimal):
        return formats.number_format(valor, decimal_pos=2)       # 70,33 (mismo formato que los templates)
    if hasattr(valor, "name") and hasattr(valor, "url"):           # archivos e imágenes (FieldFile)
        return valor.name or ""
    return "" if valor is None else str(valor)


def valor_excel(valor):
    """En Excel los números deben quedar como números (para poder sumar y ordenar)."""
    if isinstance(valor, bool):
        return "Sí" if valor else "No"
    if isinstance(valor, Decimal):
        return float(valor)
    if isinstance(valor, (int, float)):
        return valor
    return texto_valor(valor)


# ---------------------------------------------------------------------
# 3. Exportar a Excel
# ---------------------------------------------------------------------
def exportar_excel(titulo, encabezados, filas, nombre_archivo):
    libro = Workbook()
    hoja = libro.active
    hoja.title = titulo[:31]                                       # Excel: máximo 31 caracteres
    hoja.append([titulo])
    hoja["A1"].font = Font(bold=True, size=14)
    hoja.append([])
    hoja.append(encabezados)
    for celda in hoja[3]:                                          # fila 3 = encabezados
        celda.font = Font(bold=True, color="FFFFFF")
        celda.fill = PatternFill("solid", fgColor="0C4B33")
    for fila in filas:
        hoja.append([valor_excel(v) for v in fila])
    for columna in hoja.columns:                                   # ancho automático aproximado
        # (la fila 1 es el título largo: no cuenta para el ancho)
        largo = max(len(str(c.value or "")) for c in columna[2:]) if len(columna) > 2 else 10
        hoja.column_dimensions[columna[0].column_letter].width = min(largo + 2, 50)
    hoja.freeze_panes = "A4"                                       # encabezados fijos al bajar
    respuesta = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    respuesta["Content-Disposition"] = f'attachment; filename="{nombre_archivo}.xlsx"'
    libro.save(respuesta)                                          # el libro se escribe DENTRO de la respuesta
    return respuesta


# ---------------------------------------------------------------------
# 4. Exportar a PDF (xhtml2pdf)
# ---------------------------------------------------------------------
def enlazar_archivos(uri, rel):
    """xhtml2pdf necesita rutas del DISCO para imágenes: /media/x.png → C:/.../media/x.png"""
    if uri.startswith(settings.MEDIA_URL):
        return str(Path(settings.MEDIA_ROOT) / uri[len(settings.MEDIA_URL):])
    if uri.startswith(settings.STATIC_URL):
        return str(Path(settings.BASE_DIR) / "static" / uri[len(settings.STATIC_URL):])
    return uri


def render_pdf(template, contexto, nombre_archivo, descargar=False):
    html = render_to_string(template, contexto)                    # 1. template + datos → HTML
    buffer = BytesIO()
    resultado = pisa.CreatePDF(html, dest=buffer, link_callback=enlazar_archivos)   # 2. HTML → PDF
    if resultado.err:
        return HttpResponse("Error al generar el PDF", status=500)
    respuesta = HttpResponse(buffer.getvalue(), content_type="application/pdf")
    modo = "attachment" if descargar else "inline"                 # inline = se abre en el navegador
    respuesta["Content-Disposition"] = f'{modo}; filename="{nombre_archivo}.pdf"'
    return respuesta
