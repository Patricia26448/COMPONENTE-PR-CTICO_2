# =====================================================================
# core/mixins.py · los COMPONENTES reutilizables del sistema
#   UsuarioRegistroMixin      guarda quién registró
#   EliminarProtegidoMixin    avisa si no se puede eliminar (ProtectedError)
#   CrudContextoMixin         título y prefijo de URLs para los templates genéricos
#   DetalleCamposMixin        datos del detalle a partir de una lista de rutas
#   FiltroCamposMixin         (1 y 2) filtros + selección de columnas
#   ExportarMixin             (3) Excel y PDF del listado filtrado
#   ComprobantePdfMixin       (5) PDF de UN registro
# Ninguno conoce a Estudiante, Matrícula, etc.: cada vista solo los configura.
# =====================================================================
from django import forms
from django.contrib import messages
from django.db import models
from django.db.models import ProtectedError
from django.http import HttpResponseRedirect
from django.utils import timezone

from .utils import exportar_excel, render_pdf, texto_valor, valor_campo


class UsuarioRegistroMixin:
    """Al guardar un formulario, anota qué usuario lo hizo."""

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)


class CrudContextoMixin:
    """Da a los templates genéricos el título de la pantalla y el prefijo de las URLs."""
    titulo = ""          # ej: "Estudiantes"
    prefijo_url = ""     # ej: "academico:estudiante"  → academico:estudiante_lista, _crear...
    tiene_pdf = True     # ¿tiene botón de comprobante PDF?

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["titulo"] = self.titulo
        contexto["prefijo"] = self.prefijo_url
        contexto["tiene_pdf"] = self.tiene_pdf
        return contexto


class DetalleCamposMixin:
    """Para DetailView: arma la lista "datos" [(título, valor)] con las rutas de campos_detalle."""
    campos_detalle = []      # [("ruta__del__campo", "Título"), ...]

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["datos"] = [(titulo, texto_valor(valor_campo(self.object, ruta)))
                             for ruta, titulo in self.campos_detalle]
        return contexto


class EliminarProtegidoMixin:
    """Para DeleteView: si el registro tiene hijos (PROTECT) muestra un mensaje en vez de un error."""
    mensaje_protegido = "No se puede eliminar: tiene registros relacionados."
    mensaje_exito = "Registro eliminado correctamente."

    def form_valid(self, form):
        try:
            respuesta = super().form_valid(form)               # aquí se intenta borrar
        except ProtectedError:
            messages.error(self.request, self.mensaje_protegido)
            return HttpResponseRedirect(self.request.path)    # vuelve a la pantalla de confirmación
        messages.success(self.request, self.mensaje_exito)
        return respuesta


# ---------------------------------------------------------------------
# COMPONENTE 1 y 2: filtros + selección de columnas
# ---------------------------------------------------------------------
class FiltroCamposMixin:
    """Componente 1: filtros + selección de columnas. Se usa con ListView."""
    filtro_form_class = None          # formulario de filtros (Form normal, todos los campos opcionales)
    campos_disponibles = []           # [("ruta__del__campo", "Título"), ...]
    campos_por_defecto = []           # rutas que se marcan si el usuario no elige

    def filtrar(self, queryset, datos):
        """Cada vista lo sobrescribe: recibe cleaned_data y devuelve el queryset filtrado."""
        return queryset

    def get_queryset(self):
        queryset = super().get_queryset()
        self.filtro_form = self.filtro_form_class(self.request.GET or None) if self.filtro_form_class else None
        if self.filtro_form is not None and self.filtro_form.is_valid():
            queryset = self.filtrar(queryset, self.filtro_form.cleaned_data)
        return queryset

    def get_campos_seleccionados(self):
        titulos = dict(self.campos_disponibles)
        elegidos = [c for c in self.request.GET.getlist("campos") if c in titulos]   # solo rutas permitidas
        elegidos = elegidos or self.campos_por_defecto or list(titulos)
        return [(c, titulos[c]) for c in elegidos]

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        campos = self.get_campos_seleccionados()
        contexto["filtro_form"] = self.filtro_form
        contexto["campos_disponibles"] = self.campos_disponibles
        contexto["campos_seleccionados"] = [c for c, _ in campos]
        contexto["encabezados"] = [t for _, t in campos]
        contexto["filas"] = [(obj, [texto_valor(valor_campo(obj, c)) for c, _ in campos])
                             for obj in contexto["object_list"]]
        consulta = self.request.GET.copy()                         # la consulta actual SIN page ni exportar
        consulta.pop("page", None)
        consulta.pop("exportar", None)
        if "campos" in consulta:                                   # en los enlaces solo viajan columnas permitidas
            consulta.setlist("campos", [c for c in consulta.getlist("campos") if c in dict(self.campos_disponibles)])
        contexto["consulta"] = consulta.urlencode()
        return contexto


# ---------------------------------------------------------------------
# COMPONENTE 3: exportar el listado (Excel y PDF)
# ---------------------------------------------------------------------
class ExportarMixin(FiltroCamposMixin):
    """Componente 2: agrega los botones Excel y PDF al listado, con los MISMOS filtros y columnas."""
    titulo_reporte = "Reporte"
    nombre_archivo = "reporte"
    template_pdf_listado = "core/pdf/listado.html"

    def filtros_aplicados(self):
        """Lista de textos como ["Carrera: Software", ...] con las etiquetas del formulario."""
        form = getattr(self, "filtro_form", None)
        if form is None or not form.is_valid():
            return []
        resultado = []
        for nombre, valor in form.cleaned_data.items():
            if valor in (None, "", []):
                continue
            campo = form.fields[nombre]
            if not isinstance(valor, models.Model) and isinstance(campo, forms.ChoiceField):
                valor = dict(campo.choices).get(valor, valor)      # choices: muestra el texto, no el código
            resultado.append(f"{campo.label or nombre.capitalize()}: {texto_valor(valor)}")
        return resultado

    def get(self, request, *args, **kwargs):
        formato = request.GET.get("exportar")
        if formato not in ("excel", "pdf"):
            return super().get(request, *args, **kwargs)            # pantalla normal
        queryset = self.get_queryset()                             # ← mismos filtros, SIN paginar
        campos = self.get_campos_seleccionados()
        encabezados = [t for _, t in campos]
        valores = [[valor_campo(obj, c) for c, _ in campos] for obj in queryset]
        if formato == "excel":
            return exportar_excel(self.titulo_reporte, encabezados, valores, self.nombre_archivo)
        contexto = {                                               # formato == "pdf"
            "titulo": self.titulo_reporte,
            "fecha": timezone.localtime(),
            "usuario": request.user,
            "total": len(valores),
            "filtros": self.filtros_aplicados(),
            "encabezados": encabezados,
            "filas": [[texto_valor(v) for v in fila] for fila in valores],
        }
        return render_pdf(self.template_pdf_listado, contexto, self.nombre_archivo)


# ---------------------------------------------------------------------
# COMPONENTE 5: comprobante PDF de UN registro
# ---------------------------------------------------------------------
class ComprobantePdfMixin:
    """Componente 3: convierte una DetailView en un PDF (comprobante de un registro)."""
    template_pdf = None
    nombre_archivo = "comprobante"

    def render_to_response(self, context, **response_kwargs):
        context["fecha"] = timezone.localtime()
        context["usuario"] = self.request.user
        return render_pdf(self.template_pdf, context, f"{self.nombre_archivo}-{self.object.pk}")
