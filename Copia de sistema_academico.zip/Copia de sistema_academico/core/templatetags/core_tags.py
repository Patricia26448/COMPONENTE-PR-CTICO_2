# =====================================================================
# core/templatetags/core_tags.py · ayudas para los templates genéricos
# =====================================================================
from django import template
from django.urls import reverse
from django.utils.html import format_html

register = template.Library()


@register.simple_tag
def ruta(prefijo, accion, pk=None):
    """{% ruta "academico:estudiante" "detalle" obj.pk %} → /academico/estudiantes/3/
    Arma el nombre de la URL: prefijo + "_" + acción (estudiante_detalle)."""
    nombre = f"{prefijo}_{accion}"
    return reverse(nombre, args=[pk] if pk is not None else [])


@register.filter
def celda(valor):
    """Dibuja un valor en la tabla: los estados y Sí/No salen como etiquetas de color."""
    texto = str(valor)
    if texto in ("Aprobado", "Sí", "Activo", "Diurna"):
        return format_html('<span class="badge text-bg-success">{}</span>', texto)
    if texto in ("Reprobado",):
        return format_html('<span class="badge text-bg-danger">{}</span>', texto)
    if texto in ("No", "Nocturna"):
        return format_html('<span class="badge text-bg-secondary">{}</span>', texto)
    return texto


@register.filter
def clase_estado(valor):
    """Para el badge de un estado de nota (aprobado / reprobado)."""
    return "success" if valor == "aprobado" else "danger"
