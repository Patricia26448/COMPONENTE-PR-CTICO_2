# =====================================================================
# academico/forms.py · formularios de los CRUD y formularios de filtros
# =====================================================================
from django import forms
from django.db.models import Q
from django.forms import inlineformset_factory

from core.forms import BootstrapForm, BootstrapModelForm, FechaInput

from .models import (
    Carrera, Curso, EstadoNota, Estudiante, Facultad, Jornada, Matricula, Nota,
    Periodo, Profesor, Seccion, Semestre, Universidad,
)


def validar_cedula(valor):
    """La cédula debe tener exactamente 10 números."""
    valor = (valor or "").strip()
    if not (valor.isdigit() and len(valor) == 10):
        raise forms.ValidationError("La cédula debe tener exactamente 10 números.")
    return valor


# =====================================================================
# FORMULARIOS DE LOS CRUD
# =====================================================================
class UniversidadForm(BootstrapModelForm):
    class Meta:
        model = Universidad
        fields = ["nombre", "siglas", "ciudad", "logo"]


class FacultadForm(BootstrapModelForm):
    class Meta:
        model = Facultad
        fields = ["universidad", "nombre", "decano"]


class CarreraForm(BootstrapModelForm):
    class Meta:
        model = Carrera
        fields = ["facultad", "codigo", "nombre", "duracion_semestres"]

    def clean_codigo(self):
        return self.cleaned_data["codigo"].strip().upper()      # el código siempre en mayúsculas


class SemestreForm(BootstrapModelForm):
    class Meta:
        model = Semestre
        fields = ["numero", "nombre"]


class PeriodoForm(BootstrapModelForm):
    class Meta:
        model = Periodo
        fields = ["nombre", "fecha_inicio", "fecha_fin", "activo"]
        widgets = {"fecha_inicio": FechaInput(), "fecha_fin": FechaInput()}


class CursoForm(BootstrapModelForm):
    class Meta:
        model = Curso
        fields = ["carrera", "semestre", "codigo", "nombre", "creditos"]

    def clean_codigo(self):
        return self.cleaned_data["codigo"].strip().upper()


class ProfesorForm(BootstrapModelForm):
    class Meta:
        model = Profesor
        fields = ["cedula", "nombres", "apellidos", "email", "titulo"]

    def clean_cedula(self):
        return validar_cedula(self.cleaned_data["cedula"])


class EstudianteForm(BootstrapModelForm):
    class Meta:
        model = Estudiante
        fields = ["cedula", "nombres", "apellidos", "email", "telefono", "fecha_nacimiento", "carrera", "foto"]
        widgets = {"fecha_nacimiento": FechaInput()}

    def clean_cedula(self):
        return validar_cedula(self.cleaned_data["cedula"])


class SeccionForm(BootstrapModelForm):
    class Meta:
        model = Seccion
        fields = ["curso", "periodo", "profesor", "paralelo", "jornada", "cupo"]

    def clean_paralelo(self):
        return self.cleaned_data["paralelo"].strip().upper()


class SeccionChoiceField(forms.ModelChoiceField):
    """Muestra la sección con su cupo: "SOF-101 A · Nocturna · 2026-1 (12/30)"."""

    def label_from_instance(self, obj):
        return f"{obj} ({obj.inscritos}/{obj.cupo})"


class MatriculaForm(BootstrapModelForm):
    seccion = SeccionChoiceField(queryset=Seccion.objects.none(), label="Sección")

    class Meta:
        model = Matricula
        fields = ["estudiante", "seccion", "fecha"]
        widgets = {"fecha": FechaInput()}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Solo secciones del periodo activo (y, al editar, la que ya tenía la matrícula)
        filtro = Q(periodo__activo=True)
        if self.instance.pk:
            filtro |= Q(pk=self.instance.seccion_id)
        self.fields["seccion"].queryset = (
            Seccion.objects.filter(filtro).select_related("curso", "periodo").prefetch_related("matriculas"))


class NotaForm(BootstrapModelForm):
    class Meta:
        model = Nota
        fields = ["n1", "n2", "n3"]                              # promedio y estado los calcula save()


# Un solo formulario de nota por matrícula (max_num=1): es "el formulario de la nota"
NotaFormSet = inlineformset_factory(
    Matricula, Nota, form=NotaForm,
    fields=["n1", "n2", "n3"], extra=1, max_num=1, can_delete=False,
)   # en el template su prefijo es "nota": nota-TOTAL_FORMS, nota-0-n1, ...


# =====================================================================
# FORMULARIOS DE FILTROS (todos los campos son opcionales)
# =====================================================================
class FiltroUniversidadForm(BootstrapForm):
    texto = forms.CharField(label="Nombre o siglas", required=False)
    ciudad = forms.CharField(label="Ciudad", required=False)


class FiltroFacultadForm(BootstrapForm):
    texto = forms.CharField(label="Nombre o decano", required=False)
    universidad = forms.ModelChoiceField(Universidad.objects.all(), label="Universidad", required=False)


class FiltroCarreraForm(BootstrapForm):
    texto = forms.CharField(label="Código o nombre", required=False)
    universidad = forms.ModelChoiceField(Universidad.objects.all(), label="Universidad", required=False)
    facultad = forms.ModelChoiceField(Facultad.objects.all(), label="Facultad", required=False)


class FiltroSemestreForm(BootstrapForm):
    texto = forms.CharField(label="Nombre", required=False)
    numero_desde = forms.IntegerField(label="Número desde", required=False, min_value=1, max_value=12)
    numero_hasta = forms.IntegerField(label="Número hasta", required=False, min_value=1, max_value=12)


class FiltroPeriodoForm(BootstrapForm):
    texto = forms.CharField(label="Nombre", required=False)
    activo = forms.ChoiceField(label="Estado", required=False,
                               choices=[("", "Todos"), ("1", "Activo"), ("0", "Inactivo")])
    anio = forms.IntegerField(label="Año de inicio", required=False, min_value=1990, max_value=2100)


class FiltroCursoForm(BootstrapForm):
    texto = forms.CharField(label="Código o nombre", required=False)
    carrera = forms.ModelChoiceField(Carrera.objects.all(), label="Carrera", required=False)
    semestre = forms.ModelChoiceField(Semestre.objects.all(), label="Semestre", required=False)


class FiltroProfesorForm(BootstrapForm):
    texto = forms.CharField(label="Cédula o apellidos", required=False)
    periodo = forms.ModelChoiceField(Periodo.objects.all(), label="Con secciones en el periodo", required=False)


class FiltroEstudianteForm(BootstrapForm):
    texto = forms.CharField(label="Nombre o cédula", required=False)
    carrera = forms.ModelChoiceField(Carrera.objects.all(), label="Carrera", required=False)
    facultad = forms.ModelChoiceField(Facultad.objects.all(), label="Facultad", required=False)
    nacido_desde = forms.DateField(label="Nacido desde", required=False, widget=FechaInput())
    nacido_hasta = forms.DateField(label="Nacido hasta", required=False, widget=FechaInput())


class FiltroSeccionForm(BootstrapForm):
    periodo = forms.ModelChoiceField(Periodo.objects.all(), label="Periodo", required=False)
    carrera = forms.ModelChoiceField(Carrera.objects.all(), label="Carrera", required=False)
    jornada = forms.ChoiceField(label="Jornada", required=False, choices=[("", "Todas")] + Jornada.choices)
    profesor = forms.ModelChoiceField(Profesor.objects.all(), label="Profesor", required=False)


class FiltroMatriculaForm(BootstrapForm):
    texto = forms.CharField(label="Cédula o apellido", required=False)
    periodo = forms.ModelChoiceField(Periodo.objects.all(), label="Periodo", required=False)
    carrera = forms.ModelChoiceField(Carrera.objects.all(), label="Carrera", required=False)
    curso = forms.ModelChoiceField(Curso.objects.all(), label="Curso", required=False)
    jornada = forms.ChoiceField(label="Jornada", required=False, choices=[("", "Todas")] + Jornada.choices)
    estado = forms.ChoiceField(label="Estado", required=False, choices=[("", "Todos")] + EstadoNota.choices)
    promedio_desde = forms.DecimalField(label="Promedio desde", required=False, min_value=0, max_value=100)
    promedio_hasta = forms.DecimalField(label="Promedio hasta", required=False, min_value=0, max_value=100)
