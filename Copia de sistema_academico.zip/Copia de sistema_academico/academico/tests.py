# =====================================================================
# academico/tests.py · pruebas automáticas de los CRUD y los componentes
# Se ejecutan con:  python manage.py test
# =====================================================================
import io
import shutil
import tempfile
from datetime import date
from decimal import Decimal

from django.contrib.auth.models import User
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.management import call_command
from django.test import TestCase, override_settings
from django.urls import reverse
from openpyxl import load_workbook
from PIL import Image

from .models import (
    Carrera, Curso, Estudiante, Facultad, Matricula, Nota, Periodo,
    Profesor, Seccion, Semestre, Universidad,
)

MEDIA_TEMPORAL = tempfile.mkdtemp()          # las fotos de prueba no ensucian la carpeta media/


def imagen_png():
    """Una imagen PNG pequeña para probar fotos y logos."""
    buffer = io.BytesIO()
    Image.new("RGB", (40, 40), (12, 75, 51)).save(buffer, "PNG")
    return SimpleUploadedFile("logo.png", buffer.getvalue(), content_type="image/png")


@override_settings(MEDIA_ROOT=MEDIA_TEMPORAL)
class BaseTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command("poblar_datos", verbosity=0)            # los mismos datos de prueba de la guía
        cls.usuario = User.objects.create_user("profe", password="clave-segura-123")

    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        shutil.rmtree(MEDIA_TEMPORAL, ignore_errors=True)

    def setUp(self):
        self.client.force_login(self.usuario)


class SeguridadTest(TestCase):
    def test_sin_sesion_va_al_login(self):
        for nombre in ("inicio", "estudiante_lista", "matricula_lista", "seccion_lista"):
            respuesta = self.client.get(reverse(f"academico:{nombre}"))
            self.assertEqual(respuesta.status_code, 302, nombre)
            self.assertIn("/login/", respuesta["Location"])


class ModelosTest(BaseTest):
    def test_promedio_y_estado(self):
        mat = Matricula.objects.first()
        Nota.objects.filter(matricula=mat).delete()
        nota = Nota.objects.create(matricula=mat, n1=Decimal(80), n2=Decimal(65), n3=Decimal(66))
        self.assertEqual(nota.promedio, Decimal("70.33"))
        self.assertEqual(nota.estado, "aprobado")
        nota.n2 = 40
        nota.save()
        self.assertEqual(nota.estado, "reprobado")

    def test_matricula_otra_carrera_y_cupo(self):
        from django.core.exceptions import ValidationError
        otra = Carrera.objects.get(codigo="IND")
        est = Estudiante.objects.create(cedula="0801010101", nombres="X", apellidos="Y", carrera=otra)
        seccion = Seccion.objects.first()
        with self.assertRaises(ValidationError):
            Matricula(estudiante=est, seccion=seccion).full_clean()
        # cupo lleno
        seccion.cupo = seccion.inscritos
        seccion.save()
        sof = Carrera.objects.get(codigo="SOF")
        nuevo = Estudiante.objects.create(cedula="0802020202", nombres="N", apellidos="M", carrera=sof)
        with self.assertRaises(ValidationError):
            Matricula(estudiante=nuevo, seccion=seccion).full_clean()


class ListadosTest(BaseTest):
    """Todas las listas, detalles y comprobantes PDF responden bien."""
    MODELOS = {
        "universidad": Universidad, "facultad": Facultad, "carrera": Carrera, "semestre": Semestre,
        "periodo": Periodo, "curso": Curso, "profesor": Profesor, "seccion": Seccion,
        "estudiante": Estudiante, "matricula": Matricula,
    }

    def test_lista_detalle_pdf_excel_de_los_10_crud(self):
        for nombre, modelo in self.MODELOS.items():
            objeto = modelo.objects.first()
            with self.subTest(nombre):
                url = lambda accion, *a: reverse(f"academico:{nombre}_{accion}", args=a)
                self.assertEqual(self.client.get(url("lista")).status_code, 200)
                self.assertEqual(self.client.get(url("crear")).status_code, 200)
                self.assertEqual(self.client.get(url("detalle", objeto.pk)).status_code, 200)
                self.assertEqual(self.client.get(url("editar", objeto.pk)).status_code, 200)
                self.assertEqual(self.client.get(url("eliminar", objeto.pk)).status_code, 200)
                pdf = self.client.get(url("pdf", objeto.pk))
                self.assertEqual(pdf.status_code, 200)
                self.assertTrue(pdf.content.startswith(b"%PDF"), "el comprobante no es un PDF")
                excel = self.client.get(url("lista") + "?exportar=excel")
                self.assertIn("spreadsheetml", excel["Content-Type"])
                listado = self.client.get(url("lista") + "?exportar=pdf")
                self.assertTrue(listado.content.startswith(b"%PDF"), "el listado no es un PDF")

    def test_inicio(self):
        respuesta = self.client.get(reverse("academico:inicio"))
        self.assertContains(respuesta, "Estudiantes")
        self.assertEqual(respuesta.context["total_estudiantes"], 15)


class FiltrosYExportacionTest(BaseTest):
    def test_filtro_columnas_y_paginacion(self):
        url = reverse("academico:estudiante_lista")
        pagina1 = self.client.get(url)
        self.assertEqual(len(pagina1.context["filas"]), 10)                 # paginado de 10
        pagina2 = self.client.get(url + "?page=2")
        self.assertEqual(len(pagina2.context["filas"]), 5)
        # el filtro de texto reduce el listado
        filtrado = self.client.get(url, {"texto": "Pérez"})
        self.assertEqual(len(filtrado.context["filas"]), 1)
        # la paginación conserva los filtros
        self.assertEqual(filtrado.context["consulta"], "texto=P%C3%A9rez")

    def test_columnas_solo_las_permitidas(self):
        url = reverse("academico:estudiante_lista")
        respuesta = self.client.get(url + "?campos=cedula&campos=user__password&campos=apellidos")
        self.assertEqual(respuesta.context["campos_seleccionados"], ["cedula", "apellidos"])
        self.assertNotContains(respuesta, "password")

    def test_excel_respeta_filtros_columnas_y_no_pagina(self):
        url = reverse("academico:estudiante_lista")
        completo = load_workbook(io.BytesIO(self.client.get(url + "?exportar=excel").content)).active
        self.assertEqual(completo.max_row, 3 + 15)                          # título, vacío, encabezados + 15 filas
        filtrado = self.client.get(url + "?texto=Mora&campos=cedula&campos=apellidos&exportar=excel")
        hoja = load_workbook(io.BytesIO(filtrado.content)).active
        self.assertEqual([c.value for c in hoja[3]], ["Cédula", "Apellidos"])
        self.assertEqual(hoja.max_row, 4)
        self.assertEqual(hoja["B4"].value, "Mora")

    def test_matriculas_filtro_por_relaciones(self):
        url = reverse("academico:matricula_lista")
        reprobados = self.client.get(url, {"estado": "reprobado", "jornada": "nocturna"})
        for obj, _ in reprobados.context["filas"]:
            self.assertEqual(obj.nota.estado, "reprobado")
            self.assertEqual(obj.seccion.jornada, "nocturna")
        aprobados = self.client.get(url, {"promedio_desde": "70", "promedio_hasta": "100"})
        self.assertTrue(all(o.nota.promedio >= 70 for o, _ in aprobados.context["filas"]))
        # promedio_desde = 0 es un valor válido (no se ignora)
        todos = self.client.get(url, {"promedio_desde": "0"})
        self.assertEqual(todos.context["paginator"].count, Matricula.objects.count())

    def test_pdf_listado_muestra_filtros(self):
        url = reverse("academico:matricula_lista")
        respuesta = self.client.get(url, {"estado": "aprobado", "exportar": "pdf"})
        self.assertTrue(respuesta.content.startswith(b"%PDF"))
        self.assertIn("inline", respuesta["Content-Disposition"])

    def test_profesor_filtro_periodo_sin_repetidos(self):
        periodo = Periodo.objects.get(activo=True)
        respuesta = self.client.get(reverse("academico:profesor_lista"), {"periodo": periodo.pk})
        ids = [o.pk for o, _ in respuesta.context["filas"]]
        self.assertEqual(len(ids), len(set(ids)))


class CrudEstudianteTest(BaseTest):
    def datos(self, **extra):
        base = {"cedula": "0905050505", "nombres": "Rosa", "apellidos": "Gómez",
                "email": "rosa@correo.com", "telefono": "0991111111", "fecha_nacimiento": "2003-05-10",
                "carrera": Carrera.objects.get(codigo="SOF").pk}
        base.update(extra)
        return base

    def test_crear_con_foto_editar_y_pdf_con_imagen(self):
        respuesta = self.client.post(reverse("academico:estudiante_crear"), self.datos(foto=imagen_png()), follow=True)
        self.assertContains(respuesta, "guardado correctamente")
        est = Estudiante.objects.get(cedula="0905050505")
        self.assertTrue(est.foto)
        self.assertEqual(est.user, self.usuario)                           # UsuarioRegistroMixin
        # edición
        self.client.post(reverse("academico:estudiante_editar", args=[est.pk]), self.datos(nombres="Rosa María"))
        est.refresh_from_db()
        self.assertEqual(est.nombres, "Rosa María")
        # comprobante PDF con la foto
        pdf = self.client.get(reverse("academico:estudiante_pdf", args=[est.pk]))
        self.assertTrue(pdf.content.startswith(b"%PDF"))
        self.assertIn("estudiante-%d.pdf" % est.pk, pdf["Content-Disposition"])

    def test_cedula_invalida(self):
        respuesta = self.client.post(reverse("academico:estudiante_crear"), self.datos(cedula="123456789"))
        self.assertContains(respuesta, "exactamente 10 números")
        self.assertFalse(Estudiante.objects.filter(nombres="Rosa").exists())

    def test_eliminar_con_matriculas_muestra_mensaje(self):
        con_matriculas = Estudiante.objects.filter(matriculas__isnull=False).first()
        respuesta = self.client.post(reverse("academico:estudiante_eliminar", args=[con_matriculas.pk]), follow=True)
        self.assertContains(respuesta, "No se puede eliminar: tiene matrículas")
        self.assertTrue(Estudiante.objects.filter(pk=con_matriculas.pk).exists())

    def test_eliminar_sin_matriculas(self):
        libre = Estudiante.objects.create(cedula="0906060606", nombres="L", apellidos="M",
                                          carrera=Carrera.objects.get(codigo="SOF"))
        self.client.post(reverse("academico:estudiante_eliminar", args=[libre.pk]))
        self.assertFalse(Estudiante.objects.filter(pk=libre.pk).exists())


class CrudMatriculaTest(BaseTest):
    def formulario(self, estudiante, seccion, n1="80", n2="65", n3="66", **extra):
        datos = {
            "estudiante": estudiante.pk, "seccion": seccion.pk, "fecha": "2026-03-20",
            "nota-TOTAL_FORMS": "1", "nota-INITIAL_FORMS": "0", "nota-MIN_NUM_FORMS": "0", "nota-MAX_NUM_FORMS": "1",
            "nota-0-n1": n1, "nota-0-n2": n2, "nota-0-n3": n3,
        }
        datos.update(extra)
        return datos

    def nuevo_estudiante(self, cedula="0907070707", carrera="SOF"):
        return Estudiante.objects.create(cedula=cedula, nombres="Nuevo", apellidos="Alumno",
                                         carrera=Carrera.objects.get(codigo=carrera))

    def test_crear_matricula_con_nota(self):
        est = self.nuevo_estudiante()
        seccion = Seccion.objects.get(curso__codigo="SOF-102", paralelo="A")
        self.client.post(reverse("academico:matricula_crear"), self.formulario(est, seccion))
        mat = Matricula.objects.get(estudiante=est)
        self.assertEqual(mat.nota.promedio, Decimal("70.33"))
        self.assertEqual(mat.nota.estado, "aprobado")
        self.assertEqual(mat.user, self.usuario)
        self.assertEqual(mat.nota.user, self.usuario)
        detalle = self.client.get(reverse("academico:matricula_detalle", args=[mat.pk]))
        self.assertContains(detalle, "70,33")
        self.assertContains(detalle, "Aprobado")

    def test_editar_nota_cambia_estado(self):
        mat = Matricula.objects.filter(nota__estado="aprobado").first()
        nota = mat.nota
        datos = self.formulario(mat.estudiante, mat.seccion, n1="80", n2="40", n3="66", **{
            "nota-INITIAL_FORMS": "1", "nota-0-id": nota.pk, "nota-0-matricula": mat.pk})
        self.client.post(reverse("academico:matricula_editar", args=[mat.pk]), datos)
        nota.refresh_from_db()
        self.assertEqual(nota.estado, "reprobado")

    def test_error_de_carrera_arriba_del_formulario(self):
        est = self.nuevo_estudiante("0908080808", carrera="IND")
        seccion = Seccion.objects.first()
        respuesta = self.client.post(reverse("academico:matricula_crear"), self.formulario(est, seccion))
        self.assertContains(respuesta, "El curso no pertenece a la carrera del estudiante.")
        self.assertFalse(Matricula.objects.filter(estudiante=est).exists())

    def test_error_de_cupo(self):
        seccion = Seccion.objects.get(curso__codigo="SOF-102", paralelo="A")
        seccion.cupo = seccion.inscritos
        seccion.save()
        est = self.nuevo_estudiante("0909090909")
        respuesta = self.client.post(reverse("academico:matricula_crear"), self.formulario(est, seccion))
        self.assertContains(respuesta, "no tiene cupo")

    def test_nota_fuera_de_rango_no_guarda_nada(self):
        est = self.nuevo_estudiante("0910101010")
        seccion = Seccion.objects.get(curso__codigo="SOF-102", paralelo="A")
        respuesta = self.client.post(reverse("academico:matricula_crear"), self.formulario(est, seccion, n1="150"))
        self.assertEqual(respuesta.status_code, 200)
        self.assertFalse(Matricula.objects.filter(estudiante=est).exists())

    def test_eliminar_matricula_borra_su_nota(self):
        mat = Matricula.objects.first()
        nota_pk = mat.nota.pk
        self.client.post(reverse("academico:matricula_eliminar", args=[mat.pk]))
        self.assertFalse(Nota.objects.filter(pk=nota_pk).exists())

    def test_matricula_sin_nota_no_rompe(self):
        est = self.nuevo_estudiante("0911111112")
        seccion = Seccion.objects.get(curso__codigo="SOF-102", paralelo="A")
        mat = Matricula.objects.create(estudiante=est, seccion=seccion)
        self.assertEqual(self.client.get(reverse("academico:matricula_detalle", args=[mat.pk])).status_code, 200)
        self.assertTrue(self.client.get(reverse("academico:matricula_pdf", args=[mat.pk])).content.startswith(b"%PDF"))
        self.assertEqual(self.client.get(reverse("academico:matricula_lista")).status_code, 200)
        self.assertEqual(self.client.get(reverse("academico:matricula_lista") + "?exportar=excel").status_code, 200)


class CrudOtrosTest(BaseTest):
    def test_un_solo_periodo_activo(self):
        datos = {"nombre": "2026-2", "fecha_inicio": "2026-09-01", "fecha_fin": "2027-01-31", "activo": "on"}
        self.client.post(reverse("academico:periodo_crear"), datos)
        self.assertEqual(Periodo.objects.filter(activo=True).count(), 1)
        self.assertTrue(Periodo.objects.get(nombre="2026-2").activo)

    def test_periodo_fechas_invalidas(self):
        datos = {"nombre": "2027-1", "fecha_inicio": "2027-05-01", "fecha_fin": "2027-01-31"}
        respuesta = self.client.post(reverse("academico:periodo_crear"), datos)
        self.assertContains(respuesta, "posterior a la de inicio")

    def test_codigo_carrera_en_mayusculas_y_facultad_unica(self):
        fac = Facultad.objects.first()
        self.client.post(reverse("academico:carrera_crear"), {
            "facultad": fac.pk, "codigo": "ele", "nombre": "Electrónica", "duracion_semestres": 8})
        self.assertTrue(Carrera.objects.filter(codigo="ELE").exists())
        respuesta = self.client.post(reverse("academico:facultad_crear"), {
            "universidad": fac.universidad_id, "nombre": fac.nombre, "decano": ""})
        self.assertEqual(respuesta.status_code, 200)                       # error de unicidad en el formulario

    def test_universidad_con_logo_sale_en_pdf(self):
        ug = Universidad.objects.get(siglas="UG")
        self.client.post(reverse("academico:universidad_editar", args=[ug.pk]), {
            "nombre": ug.nombre, "siglas": "UG", "ciudad": "Guayaquil", "logo": imagen_png()})
        ug.refresh_from_db()
        self.assertTrue(ug.logo)
        sof = Carrera.objects.get(codigo="SOF")
        pdf = self.client.get(reverse("academico:carrera_pdf", args=[sof.pk]))
        self.assertTrue(pdf.content.startswith(b"%PDF"))
        self.assertGreater(len(pdf.content), 1000)

    def test_universidad_con_facultades_no_se_elimina(self):
        ug = Universidad.objects.get(siglas="UG")
        respuesta = self.client.post(reverse("academico:universidad_eliminar", args=[ug.pk]), follow=True)
        self.assertContains(respuesta, "No se puede eliminar")
        self.assertTrue(Universidad.objects.filter(pk=ug.pk).exists())

    def test_seccion_repetida_no_se_puede(self):
        s = Seccion.objects.first()
        respuesta = self.client.post(reverse("academico:seccion_crear"), {
            "curso": s.curso_id, "periodo": s.periodo_id, "profesor": s.profesor_id,
            "paralelo": s.paralelo, "jornada": s.jornada, "cupo": 30})
        self.assertEqual(respuesta.status_code, 200)

    def test_acta_de_seccion_pdf(self):
        s = Seccion.objects.first()
        pdf = self.client.get(reverse("academico:seccion_pdf", args=[s.pk]))
        self.assertTrue(pdf.content.startswith(b"%PDF"))
