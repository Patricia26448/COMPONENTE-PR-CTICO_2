# =====================================================================
# academico/views.py · TODAS las vistas son basadas en clases
# Reglas: LoginRequiredMixin siempre PRIMERO en la herencia y la vista genérica (ListView,
# CreateView...) siempre AL FINAL. Los componentes de core solo se configuran aquí.
# =====================================================================
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.messages.views import SuccessMessageMixin
from django.db import transaction
from django.db.models import Count, Q
from django.http import HttpResponseRedirect
from django.urls import reverse_lazy
from django.views.generic import (
    CreateView, DeleteView, DetailView, ListView, TemplateView, UpdateView,
)

from core.mixins import (
    ComprobantePdfMixin, CrudContextoMixin, DetalleCamposMixin, EliminarProtegidoMixin,
    ExportarMixin, UsuarioRegistroMixin,
)

from .forms import (
    CarreraForm, CursoForm, EstudianteForm, FacultadForm, FiltroCarreraForm, FiltroCursoForm,
    FiltroEstudianteForm, FiltroFacultadForm, FiltroMatriculaForm, FiltroPeriodoForm,
    FiltroProfesorForm, FiltroSeccionForm, FiltroSemestreForm, FiltroUniversidadForm,
    MatriculaForm, NotaFormSet, PeriodoForm, ProfesorForm, SeccionForm, SemestreForm,
    UniversidadForm,
)
from .models import (
    Carrera, Curso, EstadoNota, Estudiante, Facultad, Matricula, Nota, Periodo, Profesor,
    Seccion, Semestre, Universidad,
)


# ---------------------------------------------------------------------
# INICIO · tarjetas con indicadores
# ---------------------------------------------------------------------
class InicioView(LoginRequiredMixin, TemplateView):
    template_name = "academico/inicio.html"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        periodo = Periodo.objects.filter(activo=True).first()
        contexto["periodo"] = periodo
        contexto["total_estudiantes"] = Estudiante.objects.count()
        contexto["total_secciones"] = Seccion.objects.filter(periodo=periodo).count() if periodo else 0
        contexto["total_matriculas"] = Matricula.objects.count()
        total = Nota.objects.count()
        aprobados = Nota.objects.filter(estado=EstadoNota.APROBADO).count()
        contexto["porcentaje_aprobados"] = round(aprobados * 100 / total, 1) if total else 0   # evita dividir entre 0
        # Reto: aprobados vs. reprobados del periodo activo
        conteo = {fila["estado"]: fila["total"] for fila in
                  Nota.objects.filter(matricula__seccion__periodo__activo=True)
                  .values("estado").annotate(total=Count("id"))}
        contexto["aprobados_periodo"] = conteo.get(EstadoNota.APROBADO, 0)
        contexto["reprobados_periodo"] = conteo.get(EstadoNota.REPROBADO, 0)
        return contexto


# ---------------------------------------------------------------------
# Universidad · CRUD completo
# ---------------------------------------------------------------------
class UniversidadListView(LoginRequiredMixin, CrudContextoMixin, ExportarMixin, ListView):
    """Listado con filtros, selección de columnas, Excel y PDF (solo configuración)."""
    queryset = Universidad.objects.prefetch_related("facultades")
    template_name = "academico/universidad_lista.html"
    paginate_by = 10
    titulo = "Universidades"
    prefijo_url = "academico:universidad"
    filtro_form_class = FiltroUniversidadForm
    campos_disponibles = [
        ("siglas", "Siglas"),
        ("nombre", "Nombre"),
        ("ciudad", "Ciudad"),
        ("total_facultades", "N.º de facultades"),
    ]
    campos_por_defecto = ["siglas", "nombre", "ciudad", "total_facultades"]
    titulo_reporte = "Listado de universidades"
    nombre_archivo = "universidades"

    def filtrar(self, queryset, datos):
        if datos.get("texto"):
            queryset = queryset.filter(Q(nombre__icontains=datos["texto"]) | Q(siglas__icontains=datos["texto"]))
        if datos.get("ciudad"):
            queryset = queryset.filter(ciudad__icontains=datos["ciudad"])
        return queryset


class UniversidadCreateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, CreateView):
    model = Universidad
    form_class = UniversidadForm
    template_name = "academico/universidad_form.html"
    success_url = reverse_lazy("academico:universidad_lista")
    success_message = "Universidad guardada correctamente."
    titulo = "Universidades"
    prefijo_url = "academico:universidad"


class UniversidadUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, UpdateView):
    model = Universidad
    form_class = UniversidadForm
    template_name = "academico/universidad_form.html"
    success_url = reverse_lazy("academico:universidad_lista")
    success_message = "Universidad actualizada correctamente."
    titulo = "Universidades"
    prefijo_url = "academico:universidad"


class UniversidadDetailView(LoginRequiredMixin, CrudContextoMixin, DetalleCamposMixin, DetailView):
    model = Universidad
    template_name = "academico/universidad_detalle.html"
    titulo = "Universidades"
    prefijo_url = "academico:universidad"
    campos_detalle = [
        ("nombre", "Nombre"),
        ("siglas", "Siglas"),
        ("ciudad", "Ciudad"),
        ("total_facultades", "Facultades"),
        ("user", "Registrado por"),
        ("fecha_modificacion", "Última modificación"),
    ]


class UniversidadDeleteView(LoginRequiredMixin, CrudContextoMixin, EliminarProtegidoMixin, DeleteView):
    model = Universidad
    template_name = "academico/universidad_eliminar.html"
    success_url = reverse_lazy("academico:universidad_lista")
    titulo = "Universidades"
    prefijo_url = "academico:universidad"
    mensaje_protegido = "No se puede eliminar: la universidad tiene facultades."
    mensaje_exito = "Universidad eliminada correctamente."


class UniversidadPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    """Comprobante PDF: "Ficha de la universidad"."""
    model = Universidad
    template_pdf = "academico/pdf/universidad_ficha.html"
    nombre_archivo = "universidad"


# ---------------------------------------------------------------------
# Facultad · CRUD completo
# ---------------------------------------------------------------------
class FacultadListView(LoginRequiredMixin, CrudContextoMixin, ExportarMixin, ListView):
    """Listado con filtros, selección de columnas, Excel y PDF (solo configuración)."""
    queryset = Facultad.objects.select_related("universidad")
    template_name = "academico/facultad_lista.html"
    paginate_by = 10
    titulo = "Facultades"
    prefijo_url = "academico:facultad"
    filtro_form_class = FiltroFacultadForm
    campos_disponibles = [
        ("universidad__siglas", "Universidad"),
        ("nombre", "Facultad"),
        ("decano", "Decano"),
    ]
    campos_por_defecto = ["universidad__siglas", "nombre", "decano"]
    titulo_reporte = "Listado de facultades"
    nombre_archivo = "facultades"

    def filtrar(self, queryset, datos):
        if datos.get("universidad"):
            queryset = queryset.filter(universidad=datos["universidad"])
        if datos.get("texto"):
            queryset = queryset.filter(Q(nombre__icontains=datos["texto"]) | Q(decano__icontains=datos["texto"]))
        return queryset


class FacultadCreateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, CreateView):
    model = Facultad
    form_class = FacultadForm
    template_name = "academico/facultad_form.html"
    success_url = reverse_lazy("academico:facultad_lista")
    success_message = "Facultad guardada correctamente."
    titulo = "Facultades"
    prefijo_url = "academico:facultad"


class FacultadUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, UpdateView):
    model = Facultad
    form_class = FacultadForm
    template_name = "academico/facultad_form.html"
    success_url = reverse_lazy("academico:facultad_lista")
    success_message = "Facultad actualizada correctamente."
    titulo = "Facultades"
    prefijo_url = "academico:facultad"


class FacultadDetailView(LoginRequiredMixin, CrudContextoMixin, DetalleCamposMixin, DetailView):
    model = Facultad
    template_name = "academico/facultad_detalle.html"
    titulo = "Facultades"
    prefijo_url = "academico:facultad"
    campos_detalle = [
        ("universidad__nombre", "Universidad"),
        ("nombre", "Facultad"),
        ("decano", "Decano"),
        ("user", "Registrado por"),
        ("fecha_modificacion", "Última modificación"),
    ]


class FacultadDeleteView(LoginRequiredMixin, CrudContextoMixin, EliminarProtegidoMixin, DeleteView):
    model = Facultad
    template_name = "academico/facultad_eliminar.html"
    success_url = reverse_lazy("academico:facultad_lista")
    titulo = "Facultades"
    prefijo_url = "academico:facultad"
    mensaje_protegido = "No se puede eliminar: la facultad tiene carreras."
    mensaje_exito = "Facultad eliminada correctamente."


class FacultadPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    """Comprobante PDF: "Ficha de la facultad"."""
    model = Facultad
    template_pdf = "academico/pdf/facultad_ficha.html"
    nombre_archivo = "facultad"


# ---------------------------------------------------------------------
# Carrera · CRUD completo
# ---------------------------------------------------------------------
class CarreraListView(LoginRequiredMixin, CrudContextoMixin, ExportarMixin, ListView):
    """Listado con filtros, selección de columnas, Excel y PDF (solo configuración)."""
    queryset = Carrera.objects.select_related("facultad__universidad")
    template_name = "academico/carrera_lista.html"
    paginate_by = 10
    titulo = "Carreras"
    prefijo_url = "academico:carrera"
    filtro_form_class = FiltroCarreraForm
    campos_disponibles = [
        ("codigo", "Código"),
        ("nombre", "Carrera"),
        ("facultad__nombre", "Facultad"),
        ("facultad__universidad__siglas", "Universidad"),
        ("duracion_semestres", "Duración (semestres)"),
    ]
    campos_por_defecto = ["codigo", "nombre", "facultad__nombre", "duracion_semestres"]
    titulo_reporte = "Listado de carreras"
    nombre_archivo = "carreras"

    def filtrar(self, queryset, datos):
        if datos.get("universidad"):
            queryset = queryset.filter(facultad__universidad=datos["universidad"])
        if datos.get("facultad"):
            queryset = queryset.filter(facultad=datos["facultad"])
        if datos.get("texto"):
            queryset = queryset.filter(Q(codigo__icontains=datos["texto"]) | Q(nombre__icontains=datos["texto"]))
        return queryset


class CarreraCreateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, CreateView):
    model = Carrera
    form_class = CarreraForm
    template_name = "academico/carrera_form.html"
    success_url = reverse_lazy("academico:carrera_lista")
    success_message = "Carrera guardada correctamente."
    titulo = "Carreras"
    prefijo_url = "academico:carrera"


class CarreraUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, UpdateView):
    model = Carrera
    form_class = CarreraForm
    template_name = "academico/carrera_form.html"
    success_url = reverse_lazy("academico:carrera_lista")
    success_message = "Carrera actualizada correctamente."
    titulo = "Carreras"
    prefijo_url = "academico:carrera"


class CarreraDetailView(LoginRequiredMixin, CrudContextoMixin, DetalleCamposMixin, DetailView):
    model = Carrera
    template_name = "academico/carrera_detalle.html"
    titulo = "Carreras"
    prefijo_url = "academico:carrera"
    campos_detalle = [
        ("codigo", "Código"),
        ("nombre", "Carrera"),
        ("facultad__nombre", "Facultad"),
        ("facultad__universidad__nombre", "Universidad"),
        ("duracion_semestres", "Duración (semestres)"),
        ("user", "Registrado por"),
    ]


class CarreraDeleteView(LoginRequiredMixin, CrudContextoMixin, EliminarProtegidoMixin, DeleteView):
    model = Carrera
    template_name = "academico/carrera_eliminar.html"
    success_url = reverse_lazy("academico:carrera_lista")
    titulo = "Carreras"
    prefijo_url = "academico:carrera"
    mensaje_protegido = "No se puede eliminar: la carrera tiene cursos o estudiantes."
    mensaje_exito = "Carrera eliminada correctamente."


class CarreraPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    """Comprobante PDF: "Malla curricular"."""
    model = Carrera
    template_pdf = "academico/pdf/carrera_malla.html"
    nombre_archivo = "carrera"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        # Cursos ordenados por semestre: así {% regroup %} en el template los agrupa bien
        contexto["cursos"] = self.object.cursos.select_related("semestre").order_by("semestre__numero", "nombre")
        contexto["universidad"] = self.object.facultad.universidad
        return contexto


# ---------------------------------------------------------------------
# Semestre · CRUD completo
# ---------------------------------------------------------------------
class SemestreListView(LoginRequiredMixin, CrudContextoMixin, ExportarMixin, ListView):
    """Listado con filtros, selección de columnas, Excel y PDF (solo configuración)."""
    queryset = Semestre.objects.all()
    template_name = "academico/semestre_lista.html"
    paginate_by = 10
    titulo = "Semestres"
    prefijo_url = "academico:semestre"
    filtro_form_class = FiltroSemestreForm
    campos_disponibles = [
        ("numero", "Número"),
        ("nombre", "Nombre"),
    ]
    campos_por_defecto = ["numero", "nombre"]
    titulo_reporte = "Listado de semestres"
    nombre_archivo = "semestres"

    def filtrar(self, queryset, datos):
        if datos.get("texto"):
            queryset = queryset.filter(nombre__icontains=datos["texto"])
        if datos.get("numero_desde") is not None:
            queryset = queryset.filter(numero__gte=datos["numero_desde"])
        if datos.get("numero_hasta") is not None:
            queryset = queryset.filter(numero__lte=datos["numero_hasta"])
        return queryset


class SemestreCreateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, CreateView):
    model = Semestre
    form_class = SemestreForm
    template_name = "academico/semestre_form.html"
    success_url = reverse_lazy("academico:semestre_lista")
    success_message = "Semestre guardado correctamente."
    titulo = "Semestres"
    prefijo_url = "academico:semestre"


class SemestreUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, UpdateView):
    model = Semestre
    form_class = SemestreForm
    template_name = "academico/semestre_form.html"
    success_url = reverse_lazy("academico:semestre_lista")
    success_message = "Semestre actualizado correctamente."
    titulo = "Semestres"
    prefijo_url = "academico:semestre"


class SemestreDetailView(LoginRequiredMixin, CrudContextoMixin, DetalleCamposMixin, DetailView):
    model = Semestre
    template_name = "academico/semestre_detalle.html"
    titulo = "Semestres"
    prefijo_url = "academico:semestre"
    campos_detalle = [
        ("numero", "Número"),
        ("nombre", "Nombre"),
        ("user", "Registrado por"),
    ]


class SemestreDeleteView(LoginRequiredMixin, CrudContextoMixin, EliminarProtegidoMixin, DeleteView):
    model = Semestre
    template_name = "academico/semestre_eliminar.html"
    success_url = reverse_lazy("academico:semestre_lista")
    titulo = "Semestres"
    prefijo_url = "academico:semestre"
    mensaje_protegido = "No se puede eliminar: el semestre tiene cursos."
    mensaje_exito = "Semestre eliminado correctamente."


class SemestrePdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    """Comprobante PDF: "Cursos del semestre"."""
    model = Semestre
    template_pdf = "academico/pdf/semestre_ficha.html"
    nombre_archivo = "semestre"


# ---------------------------------------------------------------------
# Periodo · CRUD completo
# ---------------------------------------------------------------------
class PeriodoListView(LoginRequiredMixin, CrudContextoMixin, ExportarMixin, ListView):
    """Listado con filtros, selección de columnas, Excel y PDF (solo configuración)."""
    queryset = Periodo.objects.all()
    template_name = "academico/periodo_lista.html"
    paginate_by = 10
    titulo = "Periodos"
    prefijo_url = "academico:periodo"
    filtro_form_class = FiltroPeriodoForm
    campos_disponibles = [
        ("nombre", "Periodo"),
        ("fecha_inicio", "Inicio"),
        ("fecha_fin", "Fin"),
        ("activo", "Activo"),
    ]
    campos_por_defecto = ["nombre", "fecha_inicio", "fecha_fin", "activo"]
    titulo_reporte = "Listado de periodos"
    nombre_archivo = "periodos"

    def filtrar(self, queryset, datos):
        if datos.get("texto"):
            queryset = queryset.filter(nombre__icontains=datos["texto"])
        if datos.get("activo"):
            queryset = queryset.filter(activo=(datos["activo"] == "1"))
        if datos.get("anio"):
            queryset = queryset.filter(fecha_inicio__year=datos["anio"])
        return queryset


class PeriodoCreateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, CreateView):
    model = Periodo
    form_class = PeriodoForm
    template_name = "academico/periodo_form.html"
    success_url = reverse_lazy("academico:periodo_lista")
    success_message = "Periodo guardado correctamente."
    titulo = "Periodos"
    prefijo_url = "academico:periodo"

    def form_valid(self, form):
        if form.cleaned_data["activo"]:                      # solo puede haber UN periodo activo
            Periodo.objects.exclude(pk=form.instance.pk).update(activo=False)   # apaga los demás
        return super().form_valid(form)


class PeriodoUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, UpdateView):
    model = Periodo
    form_class = PeriodoForm
    template_name = "academico/periodo_form.html"
    success_url = reverse_lazy("academico:periodo_lista")
    success_message = "Periodo actualizado correctamente."
    titulo = "Periodos"
    prefijo_url = "academico:periodo"

    def form_valid(self, form):
        if form.cleaned_data["activo"]:                      # solo puede haber UN periodo activo
            Periodo.objects.exclude(pk=form.instance.pk).update(activo=False)   # apaga los demás
        return super().form_valid(form)


class PeriodoDetailView(LoginRequiredMixin, CrudContextoMixin, DetalleCamposMixin, DetailView):
    model = Periodo
    template_name = "academico/periodo_detalle.html"
    titulo = "Periodos"
    prefijo_url = "academico:periodo"
    campos_detalle = [
        ("nombre", "Periodo"),
        ("fecha_inicio", "Inicio"),
        ("fecha_fin", "Fin"),
        ("activo", "Activo"),
        ("user", "Registrado por"),
    ]


class PeriodoDeleteView(LoginRequiredMixin, CrudContextoMixin, EliminarProtegidoMixin, DeleteView):
    model = Periodo
    template_name = "academico/periodo_eliminar.html"
    success_url = reverse_lazy("academico:periodo_lista")
    titulo = "Periodos"
    prefijo_url = "academico:periodo"
    mensaje_protegido = "No se puede eliminar: el periodo tiene secciones."
    mensaje_exito = "Periodo eliminado correctamente."


class PeriodoPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    """Comprobante PDF: "Resumen del periodo"."""
    model = Periodo
    template_pdf = "academico/pdf/periodo_resumen.html"
    nombre_archivo = "periodo"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        secciones = self.object.secciones.select_related("curso", "profesor").prefetch_related("matriculas")
        contexto["secciones"] = secciones
        contexto["total_inscritos"] = sum(s.inscritos for s in secciones)
        return contexto


# ---------------------------------------------------------------------
# Curso · CRUD completo
# ---------------------------------------------------------------------
class CursoListView(LoginRequiredMixin, CrudContextoMixin, ExportarMixin, ListView):
    """Listado con filtros, selección de columnas, Excel y PDF (solo configuración)."""
    queryset = Curso.objects.select_related("carrera", "semestre")
    template_name = "academico/curso_lista.html"
    paginate_by = 10
    titulo = "Cursos"
    prefijo_url = "academico:curso"
    filtro_form_class = FiltroCursoForm
    campos_disponibles = [
        ("codigo", "Código"),
        ("nombre", "Curso"),
        ("carrera__nombre", "Carrera"),
        ("semestre", "Semestre"),
        ("creditos", "Créditos"),
    ]
    campos_por_defecto = ["codigo", "nombre", "carrera__nombre", "semestre", "creditos"]
    titulo_reporte = "Listado de cursos"
    nombre_archivo = "cursos"

    def filtrar(self, queryset, datos):
        if datos.get("carrera"):
            queryset = queryset.filter(carrera=datos["carrera"])
        if datos.get("semestre"):
            queryset = queryset.filter(semestre=datos["semestre"])
        if datos.get("texto"):
            queryset = queryset.filter(Q(codigo__icontains=datos["texto"]) | Q(nombre__icontains=datos["texto"]))
        return queryset


class CursoCreateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, CreateView):
    model = Curso
    form_class = CursoForm
    template_name = "academico/curso_form.html"
    success_url = reverse_lazy("academico:curso_lista")
    success_message = "Curso guardado correctamente."
    titulo = "Cursos"
    prefijo_url = "academico:curso"


class CursoUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, UpdateView):
    model = Curso
    form_class = CursoForm
    template_name = "academico/curso_form.html"
    success_url = reverse_lazy("academico:curso_lista")
    success_message = "Curso actualizado correctamente."
    titulo = "Cursos"
    prefijo_url = "academico:curso"


class CursoDetailView(LoginRequiredMixin, CrudContextoMixin, DetalleCamposMixin, DetailView):
    model = Curso
    template_name = "academico/curso_detalle.html"
    titulo = "Cursos"
    prefijo_url = "academico:curso"
    campos_detalle = [
        ("codigo", "Código"),
        ("nombre", "Curso"),
        ("carrera__nombre", "Carrera"),
        ("semestre", "Semestre"),
        ("creditos", "Créditos"),
        ("user", "Registrado por"),
    ]


class CursoDeleteView(LoginRequiredMixin, CrudContextoMixin, EliminarProtegidoMixin, DeleteView):
    model = Curso
    template_name = "academico/curso_eliminar.html"
    success_url = reverse_lazy("academico:curso_lista")
    titulo = "Cursos"
    prefijo_url = "academico:curso"
    mensaje_protegido = "No se puede eliminar: el curso tiene secciones."
    mensaje_exito = "Curso eliminado correctamente."


class CursoPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    """Comprobante PDF: "Ficha del curso"."""
    model = Curso
    template_pdf = "academico/pdf/curso_ficha.html"
    nombre_archivo = "curso"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["secciones"] = self.object.secciones.select_related("periodo", "profesor").prefetch_related("matriculas")
        contexto["universidad"] = self.object.carrera.facultad.universidad
        return contexto


# ---------------------------------------------------------------------
# Profesor · CRUD completo
# ---------------------------------------------------------------------
class ProfesorListView(LoginRequiredMixin, CrudContextoMixin, ExportarMixin, ListView):
    """Listado con filtros, selección de columnas, Excel y PDF (solo configuración)."""
    queryset = Profesor.objects.all()
    template_name = "academico/profesor_lista.html"
    paginate_by = 10
    titulo = "Profesores"
    prefijo_url = "academico:profesor"
    filtro_form_class = FiltroProfesorForm
    campos_disponibles = [
        ("cedula", "Cédula"),
        ("apellidos", "Apellidos"),
        ("nombres", "Nombres"),
        ("titulo", "Título"),
        ("email", "Correo"),
    ]
    campos_por_defecto = ["cedula", "apellidos", "nombres", "titulo"]
    titulo_reporte = "Listado de profesores"
    nombre_archivo = "profesores"

    def filtrar(self, queryset, datos):
        if datos.get("texto"):
            queryset = queryset.filter(Q(cedula__icontains=datos["texto"]) | Q(apellidos__icontains=datos["texto"])
                                       | Q(nombres__icontains=datos["texto"]))
        if datos.get("periodo"):                              # un profesor con 2 secciones saldría 2 veces:
            queryset = queryset.filter(secciones__periodo=datos["periodo"]).distinct()   # por eso distinct()
        return queryset


class ProfesorCreateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, CreateView):
    model = Profesor
    form_class = ProfesorForm
    template_name = "academico/profesor_form.html"
    success_url = reverse_lazy("academico:profesor_lista")
    success_message = "Profesor guardado correctamente."
    titulo = "Profesores"
    prefijo_url = "academico:profesor"


class ProfesorUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, UpdateView):
    model = Profesor
    form_class = ProfesorForm
    template_name = "academico/profesor_form.html"
    success_url = reverse_lazy("academico:profesor_lista")
    success_message = "Profesor actualizado correctamente."
    titulo = "Profesores"
    prefijo_url = "academico:profesor"


class ProfesorDetailView(LoginRequiredMixin, CrudContextoMixin, DetalleCamposMixin, DetailView):
    model = Profesor
    template_name = "academico/profesor_detalle.html"
    titulo = "Profesores"
    prefijo_url = "academico:profesor"
    campos_detalle = [
        ("cedula", "Cédula"),
        ("apellidos", "Apellidos"),
        ("nombres", "Nombres"),
        ("email", "Correo"),
        ("titulo", "Título"),
        ("user", "Registrado por"),
    ]


class ProfesorDeleteView(LoginRequiredMixin, CrudContextoMixin, EliminarProtegidoMixin, DeleteView):
    model = Profesor
    template_name = "academico/profesor_eliminar.html"
    success_url = reverse_lazy("academico:profesor_lista")
    titulo = "Profesores"
    prefijo_url = "academico:profesor"
    mensaje_protegido = "No se puede eliminar: el profesor tiene secciones asignadas."
    mensaje_exito = "Profesor eliminado correctamente."


class ProfesorPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    """Comprobante PDF: "Carga académica"."""
    model = Profesor
    template_pdf = "academico/pdf/profesor_carga.html"
    nombre_archivo = "profesor"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        # Solo las secciones del periodo activo
        contexto["secciones"] = (self.object.secciones.filter(periodo__activo=True)
                                 .select_related("curso", "periodo").prefetch_related("matriculas"))
        contexto["periodo"] = Periodo.objects.filter(activo=True).first()
        return contexto


# ---------------------------------------------------------------------
# Seccion · CRUD completo
# ---------------------------------------------------------------------
class SeccionListView(LoginRequiredMixin, CrudContextoMixin, ExportarMixin, ListView):
    """Listado con filtros, selección de columnas, Excel y PDF (solo configuración)."""
    queryset = Seccion.objects.select_related("curso__carrera", "periodo", "profesor").prefetch_related("matriculas")
    template_name = "academico/seccion_lista.html"
    paginate_by = 10
    titulo = "Secciones"
    prefijo_url = "academico:seccion"
    filtro_form_class = FiltroSeccionForm
    campos_disponibles = [
        ("curso", "Curso"),
        ("paralelo", "Paralelo"),
        ("jornada", "Jornada"),
        ("periodo", "Periodo"),
        ("profesor", "Profesor"),
        ("cupo", "Cupo"),
        ("inscritos", "Inscritos"),
    ]
    campos_por_defecto = ["curso", "paralelo", "jornada", "profesor", "cupo", "inscritos"]
    titulo_reporte = "Listado de secciones"
    nombre_archivo = "secciones"

    def filtrar(self, queryset, datos):
        if datos.get("periodo"):
            queryset = queryset.filter(periodo=datos["periodo"])
        if datos.get("carrera"):
            queryset = queryset.filter(curso__carrera=datos["carrera"])
        if datos.get("jornada"):
            queryset = queryset.filter(jornada=datos["jornada"])
        if datos.get("profesor"):
            queryset = queryset.filter(profesor=datos["profesor"])
        return queryset


class SeccionCreateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, CreateView):
    model = Seccion
    form_class = SeccionForm
    template_name = "academico/seccion_form.html"
    success_url = reverse_lazy("academico:seccion_lista")
    success_message = "Sección guardada correctamente."
    titulo = "Secciones"
    prefijo_url = "academico:seccion"


class SeccionUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, UpdateView):
    model = Seccion
    form_class = SeccionForm
    template_name = "academico/seccion_form.html"
    success_url = reverse_lazy("academico:seccion_lista")
    success_message = "Sección actualizada correctamente."
    titulo = "Secciones"
    prefijo_url = "academico:seccion"


class SeccionDetailView(LoginRequiredMixin, CrudContextoMixin, DetalleCamposMixin, DetailView):
    model = Seccion
    template_name = "academico/seccion_detalle.html"
    titulo = "Secciones"
    prefijo_url = "academico:seccion"
    campos_detalle = [
        ("curso", "Curso"),
        ("periodo", "Periodo"),
        ("profesor", "Profesor"),
        ("paralelo", "Paralelo"),
        ("jornada", "Jornada"),
        ("cupo", "Cupo"),
        ("inscritos", "Inscritos"),
        ("user", "Registrado por"),
    ]


class SeccionDeleteView(LoginRequiredMixin, CrudContextoMixin, EliminarProtegidoMixin, DeleteView):
    model = Seccion
    template_name = "academico/seccion_eliminar.html"
    success_url = reverse_lazy("academico:seccion_lista")
    titulo = "Secciones"
    prefijo_url = "academico:seccion"
    mensaje_protegido = "No se puede eliminar: la sección tiene matrículas."
    mensaje_exito = "Sección eliminada correctamente."


class SeccionPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    """Comprobante PDF: "Acta de calificaciones"."""
    model = Seccion
    template_pdf = "academico/pdf/seccion_acta.html"
    nombre_archivo = "seccion"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["matriculas"] = (self.object.matriculas.select_related("estudiante", "nota")
                                  .order_by("estudiante__apellidos", "estudiante__nombres"))
        contexto["universidad"] = self.object.curso.carrera.facultad.universidad
        return contexto


# ---------------------------------------------------------------------
# Estudiante · CRUD completo
# ---------------------------------------------------------------------
class EstudianteListView(LoginRequiredMixin, CrudContextoMixin, ExportarMixin, ListView):
    """Listado con filtros, selección de columnas, Excel y PDF (solo configuración)."""
    queryset = Estudiante.objects.select_related("carrera__facultad")
    template_name = "academico/estudiante_lista.html"
    paginate_by = 10
    titulo = "Estudiantes"
    prefijo_url = "academico:estudiante"
    filtro_form_class = FiltroEstudianteForm
    campos_disponibles = [
        ("cedula", "Cédula"),
        ("apellidos", "Apellidos"),
        ("nombres", "Nombres"),
        ("email", "Correo"),
        ("telefono", "Teléfono"),
        ("fecha_nacimiento", "Nacimiento"),
        ("carrera__nombre", "Carrera"),
        ("carrera__facultad__nombre", "Facultad"),
    ]
    campos_por_defecto = ["cedula", "apellidos", "nombres", "carrera__nombre"]
    titulo_reporte = "Listado de estudiantes"
    nombre_archivo = "estudiantes"

    def filtrar(self, queryset, datos):
        if datos.get("texto"):
            texto = datos["texto"]
            queryset = queryset.filter(Q(nombres__icontains=texto) | Q(apellidos__icontains=texto) | Q(cedula__icontains=texto))
        if datos.get("carrera"):
            queryset = queryset.filter(carrera=datos["carrera"])
        if datos.get("facultad"):
            queryset = queryset.filter(carrera__facultad=datos["facultad"])
        if datos.get("nacido_desde"):
            queryset = queryset.filter(fecha_nacimiento__gte=datos["nacido_desde"])
        if datos.get("nacido_hasta"):
            queryset = queryset.filter(fecha_nacimiento__lte=datos["nacido_hasta"])
        return queryset


class EstudianteCreateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, CreateView):
    model = Estudiante
    form_class = EstudianteForm
    template_name = "academico/estudiante_form.html"
    success_url = reverse_lazy("academico:estudiante_lista")
    success_message = "Estudiante guardado correctamente."
    titulo = "Estudiantes"
    prefijo_url = "academico:estudiante"


class EstudianteUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin, UpdateView):
    model = Estudiante
    form_class = EstudianteForm
    template_name = "academico/estudiante_form.html"
    success_url = reverse_lazy("academico:estudiante_lista")
    success_message = "Estudiante actualizado correctamente."
    titulo = "Estudiantes"
    prefijo_url = "academico:estudiante"


class EstudianteDetailView(LoginRequiredMixin, CrudContextoMixin, DetalleCamposMixin, DetailView):
    model = Estudiante
    template_name = "academico/estudiante_detalle.html"
    titulo = "Estudiantes"
    prefijo_url = "academico:estudiante"
    campos_detalle = [
        ("cedula", "Cédula"),
        ("apellidos", "Apellidos"),
        ("nombres", "Nombres"),
        ("email", "Correo"),
        ("telefono", "Teléfono"),
        ("fecha_nacimiento", "Fecha de nacimiento"),
        ("carrera__nombre", "Carrera"),
        ("carrera__facultad__nombre", "Facultad"),
        ("user", "Registrado por"),
    ]


class EstudianteDeleteView(LoginRequiredMixin, CrudContextoMixin, EliminarProtegidoMixin, DeleteView):
    model = Estudiante
    template_name = "academico/estudiante_eliminar.html"
    success_url = reverse_lazy("academico:estudiante_lista")
    titulo = "Estudiantes"
    prefijo_url = "academico:estudiante"
    mensaje_protegido = "No se puede eliminar: tiene matrículas."
    mensaje_exito = "Estudiante eliminado correctamente."


class EstudiantePdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    """Comprobante PDF: "Ficha del estudiante"."""
    model = Estudiante
    template_pdf = "academico/pdf/estudiante_ficha.html"
    nombre_archivo = "estudiante"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        # select_related: trae sección, periodo y nota en la misma consulta (no una por fila)
        contexto["matriculas"] = (self.object.matriculas
                                  .select_related("seccion__curso", "seccion__periodo", "seccion__profesor", "nota")
                                  .order_by("-seccion__periodo__fecha_inicio", "seccion__curso__codigo"))
        contexto["universidad"] = self.object.carrera.facultad.universidad
        return contexto


# ---------------------------------------------------------------------
# Matricula · CRUD completo
# ---------------------------------------------------------------------
class MatriculaListView(LoginRequiredMixin, CrudContextoMixin, ExportarMixin, ListView):
    """Listado con filtros, selección de columnas, Excel y PDF (solo configuración)."""
    queryset = Matricula.objects.select_related("estudiante", "seccion__curso", "seccion__periodo", "seccion__profesor", "nota")
    template_name = "academico/matricula_lista.html"
    paginate_by = 10
    titulo = "Matrículas y notas"
    prefijo_url = "academico:matricula"
    filtro_form_class = FiltroMatriculaForm
    campos_disponibles = [
        ("estudiante__cedula", "Cédula"),
        ("estudiante", "Estudiante"),
        ("seccion__curso__nombre", "Curso"),
        ("seccion__paralelo", "Paralelo"),
        ("seccion__jornada", "Jornada"),
        ("seccion__periodo__nombre", "Periodo"),
        ("seccion__profesor", "Profesor"),
        ("nota__n1", "Nota 1"),
        ("nota__n2", "Nota 2"),
        ("nota__n3", "Nota 3"),
        ("nota__promedio", "Promedio"),
        ("nota__estado", "Estado"),
        ("fecha", "Fecha"),
    ]
    campos_por_defecto = ["estudiante__cedula", "estudiante", "seccion__curso__nombre", "seccion__jornada", "nota__promedio", "nota__estado"]
    titulo_reporte = "Reporte de matrículas y notas"
    nombre_archivo = "matriculas"

    def filtrar(self, queryset, datos):
        if datos.get("texto"):
            queryset = queryset.filter(Q(estudiante__cedula__icontains=datos["texto"]) | Q(estudiante__apellidos__icontains=datos["texto"]))
        if datos.get("periodo"):
            queryset = queryset.filter(seccion__periodo=datos["periodo"])
        if datos.get("carrera"):
            queryset = queryset.filter(seccion__curso__carrera=datos["carrera"])
        if datos.get("curso"):
            queryset = queryset.filter(seccion__curso=datos["curso"])
        if datos.get("jornada"):
            queryset = queryset.filter(seccion__jornada=datos["jornada"])               # Matrícula → Sección
        if datos.get("estado"):
            queryset = queryset.filter(nota__estado=datos["estado"])                    # Matrícula → Nota (1:1)
        if datos.get("promedio_desde") is not None:                                     # 0 es un valor válido
            queryset = queryset.filter(nota__promedio__gte=datos["promedio_desde"])
        if datos.get("promedio_hasta") is not None:
            queryset = queryset.filter(nota__promedio__lte=datos["promedio_hasta"])
        return queryset


class MatriculaNotaMixin(CrudContextoMixin):
    """Formulario MAESTRO (Matrícula) + DETALLE 1:1 (Nota) en una sola pantalla."""
    form_class = MatriculaForm
    template_name = "academico/matricula_form.html"
    success_url = reverse_lazy("academico:matricula_lista")
    titulo = "Matrículas y notas"
    prefijo_url = "academico:matricula"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        if "nota_formset" not in contexto:                              # si vino con errores, ya está
            contexto["nota_formset"] = NotaFormSet(instance=self.object, prefix="nota")
        return contexto

    def post(self, request, *args, **kwargs):
        form = self.get_form()
        # El formset se une a la matrícula que se está editando (o a una nueva, vacía)
        formset = NotaFormSet(request.POST, instance=self.object, prefix="nota")
        if form.is_valid() and formset.is_valid():                      # validamos LOS DOS
            return self.form_valid(form, formset)
        return self.form_invalid(form, formset)

    def form_valid(self, form, formset):
        with transaction.atomic():                                      # o se guardan los dos, o ninguno
            matricula = form.save(commit=False)
            matricula.user = self.request.user
            matricula.save()
            formset.instance = matricula
            for nota in formset.save(commit=False):
                nota.user = self.request.user
                nota.save()                                             # save() calcula promedio y estado
        messages.success(self.request, self.mensaje_exito)
        return HttpResponseRedirect(self.success_url)

    def form_invalid(self, form, formset=None):
        # Vuelve a mostrar los DOS formularios con sus errores (cupo, carrera, notas fuera de 0-100...)
        return self.render_to_response(self.get_context_data(form=form, nota_formset=formset))


class MatriculaCreateView(LoginRequiredMixin, MatriculaNotaMixin, CreateView):
    model = Matricula
    mensaje_exito = "Matrícula guardada correctamente."

    def post(self, request, *args, **kwargs):
        self.object = None
        return super().post(request, *args, **kwargs)


class MatriculaUpdateView(LoginRequiredMixin, MatriculaNotaMixin, UpdateView):
    model = Matricula
    mensaje_exito = "Matrícula actualizada correctamente."

    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        return super().post(request, *args, **kwargs)


class MatriculaDetailView(LoginRequiredMixin, CrudContextoMixin, DetalleCamposMixin, DetailView):
    model = Matricula
    template_name = "academico/matricula_detalle.html"
    titulo = "Matrículas y notas"
    prefijo_url = "academico:matricula"
    campos_detalle = [
        ("estudiante", "Estudiante"),
        ("estudiante__cedula", "Cédula"),
        ("estudiante__carrera__nombre", "Carrera"),
        ("seccion", "Sección"),
        ("seccion__profesor", "Profesor"),
        ("fecha", "Fecha de matrícula"),
        ("user", "Registrado por"),
    ]


class MatriculaDeleteView(LoginRequiredMixin, CrudContextoMixin, EliminarProtegidoMixin, DeleteView):
    model = Matricula
    template_name = "academico/matricula_eliminar.html"
    success_url = reverse_lazy("academico:matricula_lista")
    titulo = "Matrículas y notas"
    prefijo_url = "academico:matricula"
    mensaje_protegido = "No se puede eliminar esta matrícula."
    mensaje_exito = "Matrícula eliminada correctamente (su nota también)."


class MatriculaPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    """Comprobante PDF: "Comprobante de matrícula"."""
    model = Matricula
    template_pdf = "academico/pdf/matricula_comprobante.html"
    nombre_archivo = "matricula"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["universidad"] = self.object.seccion.curso.carrera.facultad.universidad
        return contexto
