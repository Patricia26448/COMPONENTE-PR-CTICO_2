# =====================================================================
# academico/management/commands/poblar_datos.py
# Crea datos de prueba. Se ejecuta con:  python manage.py poblar_datos
# Usa get_or_create: si lo ejecutas dos veces, no duplica nada.
# =====================================================================
from datetime import date
from decimal import Decimal

from django.core.management.base import BaseCommand

from academico.models import (
    Carrera, Curso, Estudiante, Facultad, Matricula, Nota, Periodo,
    Profesor, Seccion, Semestre, Universidad,
)


class Command(BaseCommand):
    help = "Crea datos de prueba para el sistema académico"

    def handle(self, *args, **options):
        # --- Universidades (2) ---
        ug, _ = Universidad.objects.get_or_create(
            nombre="Universidad de Guayaquil", defaults={"siglas": "UG", "ciudad": "Guayaquil"})
        espol, _ = Universidad.objects.get_or_create(
            nombre="Escuela Politécnica del Litoral", defaults={"siglas": "ESPOL", "ciudad": "Guayaquil"})

        # --- Facultades (3) ---
        fac_cmf, _ = Facultad.objects.get_or_create(
            universidad=ug, nombre="Ciencias Matemáticas y Físicas", defaults={"decano": "Dr. Luis Andrade"})
        fac_ind, _ = Facultad.objects.get_or_create(
            universidad=ug, nombre="Ingeniería Industrial", defaults={"decano": "Ing. Rosa Mendoza"})
        fac_fiec, _ = Facultad.objects.get_or_create(
            universidad=espol, nombre="Ing. Electricidad y Computación", defaults={"decano": "Dr. Pablo Cedeño"})

        # --- Carreras (3) ---
        sof, _ = Carrera.objects.get_or_create(
            codigo="SOF", defaults={"facultad": fac_cmf, "nombre": "Software", "duracion_semestres": 8})
        Carrera.objects.get_or_create(
            codigo="RED", defaults={"facultad": fac_cmf, "nombre": "Redes y Telecomunicaciones", "duracion_semestres": 8})
        Carrera.objects.get_or_create(
            codigo="IND", defaults={"facultad": fac_ind, "nombre": "Ingeniería Industrial", "duracion_semestres": 10})

        # --- Semestres (2) y periodo activo (1) ---
        sem1, _ = Semestre.objects.get_or_create(numero=1, defaults={"nombre": "Primer semestre"})
        sem2, _ = Semestre.objects.get_or_create(numero=2, defaults={"nombre": "Segundo semestre"})
        periodo, _ = Periodo.objects.get_or_create(
            nombre="2026-1",
            defaults={"fecha_inicio": date(2026, 4, 1), "fecha_fin": date(2026, 8, 31), "activo": True})

        # --- Cursos (6) ---
        datos_cursos = [
            ("SOF-101", "Programación I", sem1, 4), ("SOF-102", "Matemática discreta", sem1, 3),
            ("SOF-103", "Fundamentos de computación", sem1, 3), ("SOF-201", "Programación II", sem2, 4),
            ("SOF-202", "Estructuras de datos", sem2, 4), ("SOF-203", "Base de datos I", sem2, 3),
        ]
        cursos = {}
        for codigo, nombre, sem, creditos in datos_cursos:
            cursos[codigo], _ = Curso.objects.get_or_create(
                codigo=codigo, defaults={"carrera": sof, "semestre": sem, "nombre": nombre, "creditos": creditos})

        # --- Profesores (3) ---
        vera, _ = Profesor.objects.get_or_create(cedula="0911111111", defaults={
            "nombres": "Carlos", "apellidos": "Vera", "email": "cvera@ug.edu.ec", "titulo": "Mg. en Software"})
        leon, _ = Profesor.objects.get_or_create(cedula="0922222222", defaults={
            "nombres": "María", "apellidos": "León", "email": "mleon@ug.edu.ec", "titulo": "Mg. en Redes"})
        Profesor.objects.get_or_create(cedula="0933333333", defaults={
            "nombres": "Jorge", "apellidos": "Paredes", "email": "jparedes@ug.edu.ec", "titulo": "PhD. en Computación"})

        # --- Secciones (4): diurnas y nocturnas ---
        s1, _ = Seccion.objects.get_or_create(
            curso=cursos["SOF-101"], periodo=periodo, paralelo="A", jornada="diurna",
            defaults={"profesor": vera, "cupo": 30})
        s2, _ = Seccion.objects.get_or_create(
            curso=cursos["SOF-101"], periodo=periodo, paralelo="B", jornada="nocturna",
            defaults={"profesor": leon, "cupo": 25})
        s3, _ = Seccion.objects.get_or_create(
            curso=cursos["SOF-102"], periodo=periodo, paralelo="A", jornada="diurna",
            defaults={"profesor": leon, "cupo": 30})
        s4, _ = Seccion.objects.get_or_create(
            curso=cursos["SOF-102"], periodo=periodo, paralelo="B", jornada="nocturna",
            defaults={"profesor": vera, "cupo": 25})
        secciones = [s1, s2, s3, s4]

        # --- Estudiantes (15) ---
        nombres = [
            ("0912345678", "Ana", "Pérez"), ("0999999999", "Luis", "Mora"), ("0988888888", "Eva", "Ruiz"),
            ("0977777777", "Diego", "Castro"), ("0966666666", "Sofía", "Vélez"), ("0955555555", "Mateo", "Zambrano"),
            ("0944444444", "Camila", "Ortiz"), ("0933333330", "Andrés", "Reyes"), ("0922222220", "Valeria", "Naranjo"),
            ("0911111110", "Javier", "Cevallos"), ("0900000001", "Lucía", "Barrera"), ("0900000002", "Pablo", "Intriago"),
            ("0900000003", "Daniela", "Salazar"), ("0900000004", "Kevin", "Macías"), ("0900000005", "Paola", "Torres"),
        ]
        estudiantes = []
        for cedula, nombre, apellido in nombres:
            est, _ = Estudiante.objects.get_or_create(cedula=cedula, defaults={
                "nombres": nombre, "apellidos": apellido, "carrera": sof,
                "email": f"{nombre.lower()}.{apellido.lower()}@correo.com".replace("í", "i").replace("é", "e").replace("á", "a"),
                "telefono": "0990000000", "fecha_nacimiento": date(2002 + len(estudiantes) % 4, 1 + len(estudiantes) % 12, 10)})
            estudiantes.append(est)

        # --- Matrículas (25) y notas variadas (algunas aprobadas, otras reprobadas) ---
        notas = [(80, 65, 66), (90, 85, 88), (60, 70, 55), (75, 80, 72), (50, 45, 60), (95, 90, 92),
                 (70, 70, 70), (40, 55, 62), (85, 78, 90), (66, 69, 71)]
        total = 0
        for i in range(25):
            est = estudiantes[i % 15]
            seccion = secciones[(i // 15) * 2 + (i % 2)]          # reparte entre las 4 secciones
            mat, creada = Matricula.objects.get_or_create(estudiante=est, seccion=seccion)
            if not hasattr(mat, "nota"):
                n1, n2, n3 = notas[i % len(notas)]
                Nota.objects.create(matricula=mat, n1=Decimal(n1), n2=Decimal(n2), n3=Decimal(n3))   # create() llama a save()
            total += creada
        self.stdout.write(self.style.SUCCESS(
            f"Datos listos: {Universidad.objects.count()} universidades, {Estudiante.objects.count()} estudiantes, "
            f"{Seccion.objects.count()} secciones, {Matricula.objects.count()} matrículas, {Nota.objects.count()} notas."))
