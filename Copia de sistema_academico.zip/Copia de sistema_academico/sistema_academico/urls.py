# =====================================================================
# sistema_academico/urls.py · rutas del proyecto
# =====================================================================
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.auth.views import LoginView, LogoutView
from django.urls import include, path
from django.views.generic import RedirectView

urlpatterns = [
    path("admin/", admin.site.urls),
    path("login/", LoginView.as_view(), name="login"),       # vistas de clase que trae Django
    path("logout/", LogoutView.as_view(), name="logout"),    # solo acepta POST
    path("academico/", include("academico.urls")),
    path("", RedirectView.as_view(pattern_name="academico:inicio", permanent=False)),
]

# En desarrollo, Django sirve las fotos y logos subidos (carpeta media/)
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
